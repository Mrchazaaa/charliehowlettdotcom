===========================================================================================================================
NOTES:
===========================================================================================================================

This game is currently in alpha version

Eventually, I plan to publish the source code for this project, after a few minor improvements and code cleaning.

===========================================================================================================================
INSTALLATION:
===========================================================================================================================

Currently, this program is intended for Linux, but I plan to publish executables designed for other enviroments in the future.

-Unpack this zip into your choice of directory.
-Launch the .x86_64 or .x86 file.
