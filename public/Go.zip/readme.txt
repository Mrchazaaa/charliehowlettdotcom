Eventually, I plan to publish the source code for this project, after a few minor improvements and code cleaning.
Currently, this program only runs on windows.
